package com.firestore;
import com.firestore.controller.login.LoginPage;


import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(LoginPage.class,args);
    }
}