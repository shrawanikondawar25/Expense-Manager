package com.firestore.expense;

public class ExpenseCategory {
	String category;
	Integer amount;
	ExpenseCategory(String cate,Integer amount){
		this.category = cate;
		this.amount = amount;
	}
	public ExpenseCategory(String formate) {
        //TODO Auto-generated constructor stub
    }
    public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
}
