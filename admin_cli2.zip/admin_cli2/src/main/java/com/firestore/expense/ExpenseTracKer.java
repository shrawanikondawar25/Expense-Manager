package com.firestore.expense;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.concurrent.ExecutionException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale.Category;
import java.util.Map;

import com.firestore.firebaseconfig.DataService;

import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firestore.v1.Document;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

public class ExpenseTracKer {

    private TableView<ExpenseTable> tableView;
    private TableView<ExpenseTable> categoryTableView;
    private static Firestore db;
    private Stage prStage;
    private Label totalExpense;
    private Label balance;
    private Label totalIncome;
    private Scene scene;
    protected Runnable logoutHandler;
    private List<String> categoryList = new ArrayList<>();

    public void setScene(Scene scene) {
        this.scene = scene;
    }

    public void setStage(Stage stage) {
        this.prStage = stage;
    }
    // public static void main(String[] args) {
    // launch(args);
    // }
    // public void createExpenseTracker(Runnable logoutHandler) {
    // initializeFirebase();
    // // Scene mainScene = setupMainScene(primaryStage);
    // // primaryStage.setTitle("Expense Tracker");
    // // primaryStage.setScene(mainScene);
    // // primaryStage.setResizable(false);
    // // prStage = primaryStage;
    // // primaryStage.show();
    // }

    public static void initializeFirebase() {
        try {
            FileInputStream serviceAccount = new FileInputStream(
                    "src\\main\\resources\\java-fx-firebase-store-16098-firebase-adminsdk-wlex1-f3206b77dd.json");
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();
            FirebaseApp.initializeApp(options);
            db = FirestoreClient.getFirestore();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // fetchSpendingDataFromFirebase();
    }

    /*
     * private void fetchSpendingDataFromFirebase() {
     * 
     * FirebaseDatabase database = FirebaseDatabase.getInstance();
     * DatabaseReference ref = database.getReference("spending");
     * 
     * ref.addListenerForSingleValueEvent(new ValueEventListener() {
     * 
     * @Override
     * public void onDataChange(DataSnapshot dataSnapshot) {
     * for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
     * String category = snapshot.child("category").getValue(String.class);
     * Double amount = snapshot.child("amount").getValue(Double.class);
     * spendingDataList.add(new SpendingData(category, amount));
     * }
     * spendingTableView.setItems(spendingDataList);
     * }
     * 
     * @Override
     * public void onCancelled(DatabaseError databaseError) {
     * System.err.println("Error: " + databaseError.getMessage());
     * }
     * });
     * }
     */

    public static Firestore getFirestore() {
        return FirestoreClient.getFirestore();
    }

    public Scene setupMainScene(Runnable logoutHandler) {
        // initializeFirebase();
        totalExpense = new Label();
        totalIncome = new Label();
        balance = new Label();
        TabPane tabPane = new TabPane();
        tabPane.setTabMinWidth(475);
        tabPane.setTabMaxHeight(200);
        tabPane.getStyleClass().add("tab-pane");

        Tab spendingTab = createTab("Spending", "Spending.png");
        Tab graphTab = createTab("Graph", "Graph.png");

        tabPane.getTabs().addAll(spendingTab, graphTab);

        spendingTab.setContent(setupSpendingPane());
        graphTab.setContent(createPieChart());

        Scene scene = new Scene(tabPane, 1000, 900);
        scene.getStylesheets().add(getClass().getResource("JavaFx.css").toExternalForm());

        return scene;
    }

    private Tab createTab(String title, String iconPath) {
        Tab tab = new Tab(title);
        tab.setClosable(false);
        ImageView tabIcon = new ImageView(new Image(iconPath));
        tabIcon.setFitHeight(50);
        tabIcon.setFitWidth(50);
        tab.setGraphic(tabIcon);
        tab.getStyleClass().add("tab-sett");
        return tab;
    }

    private VBox setupSpendingPane() {
        categoryTableView = new TableView<>();
        // categoryTableView.getColumns().addAll(createCategoryColumn("Category",
        // "category", 205));

        TableColumn<ExpenseTable, String> categoryColumn = new TableColumn<>("Category");
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        categoryColumn.setPrefWidth(245);

        TableColumn<ExpenseTable, Double> amountColumn = new TableColumn<>("Amount");
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("amount"));
        amountColumn.setPrefWidth(245);

        TableColumn<ExpenseTable, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        dateColumn.setPrefWidth(245);

        TableColumn<ExpenseTable, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        descriptionColumn.setPrefWidth(245);

       

        categoryTableView.getColumns().add(categoryColumn);
        categoryTableView.getColumns().add(amountColumn);
        categoryTableView.getColumns().add(dateColumn);
        categoryTableView.getColumns().add(descriptionColumn);
       

        // categoryTableView.setItems(getCategory());
        categoryTableView.setStyle("-fx-pref-height : 850");
        System.out.println(getDataList("transaction"));
        Show();

        ObservableList<ExpenseTable> expenses = FXCollections.observableArrayList(getDataList("transaction"));
        categoryTableView.setItems(expenses);

        Button addExpenseButton = new Button("+ Expense");
        addExpenseButton.getStyleClass().add("Basescene-button");
        categoryTableView.setStyle("-fx-pref-height : 850");
        // addExpenseButton.setOnAction(e -> openPopup());

        addExpenseButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                Popup popup = new Popup();

                // Create content for the popup
                VBox popupContent = new VBox();
                popupContent.setStyle("-fx-background-color: lightgray; -fx-padding: 10;");

                Label categoryLabel = new Label("Category");
                Label amountLabel = new Label("Amount");
                Label dateLabel = new Label("Date");
                Label descriptionLabel = new Label("Description");

                ChoiceBox<String> categoryChoiceBox = new ChoiceBox<>();
                categoryChoiceBox.getItems().addAll("Food", "Transport", "Entertainment", "Utilities", "Health",
                        "Education", "Miscellaneous", "Other");

                TextField amountField = new TextField();

                DatePicker datePicker = new DatePicker(LocalDate.now());
                TextField descriptionField = new TextField();

                Button saveButton = new Button("Save");
                saveButton.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        String selectedCategory = categoryChoiceBox.getValue();
                        LocalDate selectedDate = datePicker.getValue();

                        ExpenseTable expense = new ExpenseTable();
                        expense.setCategory(selectedCategory);
                        expense.setAmount(amountField.getText());
                        expense.setDate(datePicker.getValue().toString());

                        expense.setDescription(descriptionField.getText());
                        expense.setType("expense");
                        saveEntry(expense);
                        popup.hide();
                    }

                });

                GridPane gridPane = new GridPane();
                gridPane.setPadding(new Insets(20));
                gridPane.setHgap(10);
                gridPane.setVgap(10);
                gridPane.add(categoryLabel, 0, 0);
                gridPane.add(categoryChoiceBox, 1, 0);
                gridPane.add(amountLabel, 0, 1);
                gridPane.add(amountField, 1, 1);
                gridPane.add(dateLabel, 0, 2);
                gridPane.add(datePicker, 1, 2);
                gridPane.add(descriptionLabel, 0, 3);

                gridPane.add(descriptionField, 1, 3);

                // gridPane.add(dateTimeLabel, 0, 6);

                gridPane.add(saveButton, 1, 4);
                popupContent.getChildren().add(gridPane);

                // Set the content for the popup
                popup.getContent().add(popupContent);

                // Show the popup
                popup.show(prStage);
                prStage.getScene().addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        if (!popupContent.getBoundsInParent().contains(event.getSceneX(), event.getSceneY())) {
                            popup.hide();
                        }
                    }
                });
            }

        });

        Button addIncomeButton = new Button("+ Income");
        addIncomeButton.getStyleClass().add("Basescene-button");
        // addIncomeButton.setOnAction(e -> openPopup());
        addIncomeButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Popup popup = new Popup();

                // Create content for the popup
                VBox popupContent = new VBox();
                popupContent.setStyle("-fx-background-color: lightgray; -fx-padding: 10;");

                Label categoryLabel = new Label("Category");
                Label amountLabel = new Label("Amount");
                Label dateLabel = new Label("Date");
                Label descriptionLabel = new Label("Description");

                ChoiceBox<String> categoryChoiceBox = new ChoiceBox<>();
                categoryChoiceBox.getItems().addAll("Allowance", "Salary", "Bonus");

                TextField amountField = new TextField();

                DatePicker datePicker = new DatePicker(LocalDate.now());
                TextField descriptionField = new TextField();

                DateTimePicker dateTimePicker = new DateTimePicker();

                Button saveButton = new Button("Save");
                saveButton.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        String selectedCategory = categoryChoiceBox.getValue();
                        LocalDate selectedDate = datePicker.getValue();

                        ExpenseTable expense = new ExpenseTable();
                        expense.setCategory(selectedCategory);
                        expense.setAmount(amountField.getText());
                        expense.setDate(datePicker.getValue().toString());

                        expense.setDescription(descriptionField.getText());
                        expense.setType("income");
                        saveEntry(expense);
                        popup.hide();
                    }

                });

                GridPane gridPane = new GridPane();
                gridPane.setPadding(new Insets(20));
                gridPane.setHgap(10);
                gridPane.setVgap(10);
                gridPane.add(categoryLabel, 0, 0);
                gridPane.add(categoryChoiceBox, 1, 0);
                gridPane.add(amountLabel, 0, 1);
                gridPane.add(amountField, 1, 1);
                gridPane.add(dateLabel, 0, 2);
                gridPane.add(datePicker, 1, 2);
                gridPane.add(descriptionLabel, 0, 3);

                gridPane.add(descriptionField, 1, 3);

                // gridPane.add(dateTimeLabel, 0, 6);

                gridPane.add(saveButton, 1, 4);
                popupContent.getChildren().add(gridPane);

                // Set the content for the popup
                popup.getContent().add(popupContent);

                // Show the popup
                popup.show(prStage);
                prStage.getScene().addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        if (!popupContent.getBoundsInParent().contains(event.getSceneX(), event.getSceneY())) {
                            popup.hide();
                        }
                    }
                });
            }

        });

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("Basescene-button");
        logoutButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Perform logout operation

            }
        });

        BorderPane buttonPane = new BorderPane();
        buttonPane.setLeft(addIncomeButton);
        BorderPane.setMargin(addIncomeButton, new Insets(22, 0, 20, 60));
        buttonPane.setRight(addExpenseButton);
        BorderPane.setMargin(addExpenseButton, new Insets(22, 60, 20, 0));

        

        HBox hb1 = new HBox(new Label("Total Expense : "), totalExpense);
        HBox hb2 = new HBox(new Label("Total income : "), totalIncome);
        HBox hb3 = new HBox(new Label("Balance        : "), balance);

        VBox vb = new VBox(hb1, hb2, hb3);

       


    Hyperlink aboutUsLink = new Hyperlink("About Us");
        aboutUsLink.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                showAboutUs();
            }
        });

        HBox linkBox = new HBox(aboutUsLink);
        linkBox.setAlignment(Pos.CENTER_RIGHT);


        VBox spendingPane = new VBox(categoryTableView,vb, buttonPane,logoutButton,aboutUsLink);
        spendingPane.setStyle("-fx-background-color:WHITE");
        return spendingPane;
    }

    private VBox createAboutUsPage() {
        VBox aboutUsPane = new VBox();
        aboutUsPane.setPadding(new Insets(20));
        aboutUsPane.setSpacing(10);
        aboutUsPane.setStyle("-fx-background-color : rgb(252,223,169)");
        

        Label title = new Label("About Us");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label description = new Label(" PROJECT OVERVIEW: \nThis application provides a comprehensive solution for tracking expenses and incomes, storing them in Firestore, and visualizing the data effectively using JavaFX components.");
        description.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        description.setWrapText(true);

        Label developerInfo = new Label("Group Members:\n 1) Pratik Jadhav\n 2) Kaustubh Shinde\n 3) Shrawani Kondawar\n 4) Sanika Ghadge ");
        developerInfo.setStyle("-fx-font-size: 18px; -fx-font-weight: arial;");
        developerInfo.setWrapText(true);

        Label Info = new Label("Special ThankYou !\n Shashi Sir\n Subodh Sir \n Sachin Sir\n Pramod sir\n Shiv Sir\n Rahul Sir");
        Info.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        Info.setAlignment(Pos.CENTER);
        Info.setWrapText(true);

        

        Image image = new Image("images/i1.jpeg"); 
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(400); 
        imageView.setPreserveRatio(true);

        aboutUsPane.getChildren().addAll(title,imageView, description, developerInfo,Info);
        return aboutUsPane;
    }


    private void showAboutUs() {
        Stage aboutUsStage = new Stage();
        aboutUsStage.setTitle("About Us");

        VBox aboutUsPane = createAboutUsPage();

        Scene aboutUsScene = new Scene(aboutUsPane, 1000, 900);
        aboutUsScene.getStylesheets().add(getClass().getResource("JavaFx.css").toExternalForm());

        aboutUsStage.setScene(aboutUsScene);
        aboutUsStage.show();
    }





    public void Show() {
        List<ExpenseTable> list = getDataList("transaction");
        ObservableList<ExpenseTable> expenses = FXCollections.observableArrayList(list);
        categoryTableView.setItems(expenses);

        double totalExpenseN = 0;
        double totalIncomeN = 0;

        for (ExpenseTable expense : list) {

            if (expense.getType().equals("income")) {
                totalIncomeN += Double.parseDouble(expense.getAmount());

            } else if (expense.getType().equals("expense")) {

                totalExpenseN += Double.parseDouble(expense.getAmount());

            }
        }

        double balanceN = totalIncomeN - totalExpenseN;
        System.out.println(balanceN);

        // double.add(new ExpenseCategory("Total Expense", Formate(totalExpense)));
        // double.add(new ExpenseCategory("Total Income", Formate(totalIncome)));
        // double.add(new ExpenseCategory("Balance", Formate(balance)));
        totalExpense.setText(String.valueOf(totalExpenseN));
        totalIncome.setText(String.valueOf(totalIncomeN));
        balance.setText(String.valueOf(balanceN));

    }

    public List<ExpenseTable> getDataList(String c2w_pi_collection) {

        try {
            CollectionReference c2w_pi_colRef = db.collection(c2w_pi_collection); // Reference to the collection

            ApiFuture<QuerySnapshot> c2w_pi_future = c2w_pi_colRef.get(); // Asynchronously retrieve all documents in
                                                                          // collection

            QuerySnapshot c2w_pi_querySnapshot = c2w_pi_future.get(); // Get query snapshot containing all documents

            List<QueryDocumentSnapshot> c2w_pi_documents = c2w_pi_querySnapshot.getDocuments(); // Extract list of
                                                                                                // document snapshots

            List<ExpenseTable> c2w_pi_dataList = new ArrayList<>();

            for (QueryDocumentSnapshot c2w_pi_document : c2w_pi_documents) {

                ExpenseTable c2w_pi_object = c2w_pi_document.toObject(ExpenseTable.class); // Convert each document
                                                                                           // snapshot to Player object

                c2w_pi_dataList.add(c2w_pi_object); // Add Player object to list
            }
            return c2w_pi_dataList; // Return list of Player objects

        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging

        }
        return new ArrayList<>();
    }

   

    

    private TableColumn<ExpenseTable, String> createColumn(String title, String property, int width) {
        TableColumn<ExpenseTable, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        column.setMinWidth(width);
        column.setSortable(false);
        return column;
    }

    private TableColumn<ExpenseCategory, String> createCategoryColumn(String title, String property, int width) {
        TableColumn<ExpenseCategory, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        column.setMinWidth(width);
        column.setSortable(false);
        return column;
    }






    private Pane setupGraphPane() {
        PieChart pieChart = new PieChart();
        //pieChart.setData(getPieChartData());
        pieChart.getStyleClass().add("Pie-chart");
        pieChart.setTitle("Spending Chart");

        Pane piePane = new Pane(pieChart);
        piePane.setStyle("-fx-background-color:#353839");
        return piePane;
    }

    /*private ObservableList<PieChart.Data> getPieChartData() {
    ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
    try {
        ApiFuture<QuerySnapshot> query = db.collection("transaction").get();
        List<QueryDocumentSnapshot> documents = query.get().getDocuments();
        Map<String, Double> categoryAmounts = new HashMap<>();

        for (QueryDocumentSnapshot document : documents) {
            String category = document.getString("category");
            Double amount = document.getDouble("amount");
            if (category != null && amount != null) {
                categoryAmounts.put(category, categoryAmounts.getOrDefault(category, 0.0) + amount);
            }
        }

        for (Map.Entry<String, Double> entry : categoryAmounts.entrySet()) {
            data.add(new PieChart.Data(entry.getKey(), entry.getValue()));
        }
    } catch (InterruptedException | ExecutionException e) {
        e.printStackTrace();
    }
    return data;

}*/


    VBox createPieChart(){

        Map<String,Double> map = getCategorywise(getDataList("transaction"));
        List<ExpenseCategory> expenses = new ArrayList<>();
        System.out.println(map);
    
    
        PieChart pieChart = new PieChart();
        for(String str : categoryList){
            PieChart.Data slice = new PieChart.Data(str, map.get(str));
            pieChart.getData().add(slice);
        }

        VBox vb = new VBox(pieChart);
        return vb;
    }

    // private ObservableList<PieChart.Data> getPieChartData() {
    //     ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
    //     try {
    //         ApiFuture<QuerySnapshot> query = db.collection("transaction").get();
    //         List<QueryDocumentSnapshot> documents = query.get().getDocuments();
    //         for (QueryDocumentSnapshot document : documents) {
    //             String category = document.getString("category");
    //             Double amount = document.getDouble("amount");
    //             if (category != null && amount != null) {
    //                 addAmountToCategory(data, category, amount);
    //             }
    //         }
    //     } catch (InterruptedException | ExecutionException e) {
    //         e.printStackTrace();
    //     }
    //     return data;
    // }

    private void addAmountToCategory(ObservableList<PieChart.Data> data, String category, Double amount) {
        for (PieChart.Data entry : data) {
            if (entry.getName().equals(category)) {
                entry.setPieValue(entry.getPieValue() + amount);
                return;
            }
        }
        data.add(new PieChart.Data(category, amount));
    }

    Map<String,Double> getCategorywise(List<ExpenseTable> list){

        Map<String,Double> map = new HashMap<>();
        

        for (ExpenseTable expense : list) {

            if(map.containsKey(expense.getCategory())){
                map.replace(expense.getCategory(), map.get(expense.getCategory())+Double.parseDouble(expense.getAmount()));
            }else{
                categoryList.add(expense.getCategory());
                System.out.println(Double.parseDouble(expense.getAmount()));
                map.put(expense.getCategory(), Double.parseDouble(expense.getAmount()));
            }
            
        }
        return map;
    }



    // private double getCategorySum(String category) throws InterruptedException, ExecutionException {
    //     double sum = 0;
    //     ApiFuture<QuerySnapshot> query = db.collection("tdtb").whereEqualTo("Category", category).get();
    //     List<QueryDocumentSnapshot> documents = query.get().getDocuments();

    //     for (QueryDocumentSnapshot document : documents) {
    //         sum += document.getDouble("trtrtr");
    //     }
    //     return sum;
    // }

    private ObservableList<ExpenseTable> getExpenseData() {
        ObservableList<ExpenseTable> data = FXCollections.observableArrayList();
        ApiFuture<QuerySnapshot> query = db.collection("tdtb").orderBy("date", Query.Direction.DESCENDING).get();

        // try {
        // List<QueryDocumentSnapshot> documents = query.get().getDocuments();
        // for (QueryDocumentSnapshot document : documents) {
        // String category = document.getString("Category");
        // Double amount = document.getDouble("trtrtr");
        // String date = document.getString("date");
        // data.add(new ExpenseTable(category, formatAmount(amount), date));
        // }
        // } catch (InterruptedException | ExecutionException e) {
        // e.printStackTrace();
        // }
        return data;
    }

    public boolean authaunticate(String email, String password){

        DocumentSnapshot document = getData("users", email);

        if (document.exists()) {
            return password.equals(document.get("password"));
        } else {
            return false;
        }
    }

    public void addData(String collection, String document , Map<String,Object> map){
        try{
            System.out.println(db);
            db.collection(collection).document(document).set(map).get();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    DocumentSnapshot getData(String collection, String document){
        try{
            ApiFuture<DocumentSnapshot> future = db.collection(collection).document(document).get();

            // Fetch the document
            DocumentSnapshot doc = future.get();
        return doc;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    /*
     * private ObservableList<ExpenseCategory> getCategoryData() {
     * ObservableList<ExpenseCategory> data = FXCollections.observableArrayList();
     * ApiFuture<QuerySnapshot> query = db.collection("Transaction").get();
     * 
     * try {
     * List<QueryDocumentSnapshot> documents = query.get().getDocuments();
     * double totalExpense = 0;
     * double totalSalary = 0;
     * 
     * // for (QueryDocumentSnapshot document : documents) {
     * // String category = document.getString("Category");
     * // System.out.println(document);
     * // double amount = document.getDouble("trtrtr");
     * 
     * // if (!category.equals("Salary")) {
     * // totalExpense += amount;
     * // data.add(new ExpenseCategory(category, formatAmount(amount)));
     * // } else {
     * // totalSalary += amount;t
     * // }
     * // }
     * 
     * data.add(new ExpenseCategory("Total Expense  --------->",
     * formatAmount(totalExpense)));
     * data.add(new ExpenseCategory("Balance", formatAmount(totalSalary)));
     * data.add(new ExpenseCategory("Total Savings  --------->",
     * formatAmount(totalSalary - totalExpense)));
     * 
     * } catch (InterruptedException | ExecutionException e) {
     * e.printStackTrace();
     * }
     * return data;
     * }
     */

    private String Formate(double amount) {
        return String.format("%.2f", amount);
    }

    private void deleteSelectedTransaction() {
        ExpenseTable selectedTransaction = tableView.getSelectionModel().getSelectedItem();
        // if (selectedTransaction != null) {
        // ApiFuture<WriteResult> writeResult =
        // db.collection("tdtb").document(selectedTransaction.getId()).delete();
        // try {
        // writeResult.get();
        // tableView.getItems().remove(selectedTransaction);
        // } catch (InterruptedException | ExecutionException e) {
        // e.printStackTrace();
        // }
        // }
    }

    private void openPopup() {
        Stage popupStage = new Stage();
        popupStage.setTitle("Entry");

        Label categoryLabel = new Label("Category");
        Label amountLabel = new Label("Amount");
        Label dateLabel = new Label("Date");

        TextField categoryField = new TextField();
        TextField amountField = new TextField();
        DatePicker datePicker = new DatePicker(LocalDate.now());

        Button saveButton = new Button("Save");
        saveButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                ExpenseTable expense = new ExpenseTable();
                expense.setCategory(categoryField.getText());
                expense.setAmount(amountField.getText());
                expense.setDate(datePicker.getValue().toString());
                expense.setDescription("ABC");
                saveEntry(expense);
            }

        });

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.add(categoryLabel, 0, 0);
        gridPane.add(categoryField, 1, 0);
        gridPane.add(amountLabel, 0, 1);
        gridPane.add(amountField, 1, 1);
        gridPane.add(dateLabel, 0, 2);
        gridPane.add(datePicker, 1, 2);
        gridPane.add(saveButton, 1, 3);

        Scene scene = new Scene(gridPane, 300, 200);
        popupStage.setScene(scene);
        popupStage.show();
    }

    private void saveEntry(ExpenseTable expense) {
        // double amount = Double.parseDouble(amountStr);
        ApiFuture<WriteResult> future = db.collection("transaction").document().set(expense);

        try {
            future.get();
            Show();
            // entryStage.close();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    private String formatAmount(double amount) {
        DecimalFormat formatter = new DecimalFormat("#.##");
        return formatter.format(amount);
    }

}
