package com.firestore.expense;

import java.time.LocalDateTime;

public class ExpenseTable {
    String category;
    String amount;
    String date;
    String description;
    String time = LocalDateTime.now().toString();
    String type;
    ExpenseTable(){}
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    @Override
    public String toString() {
        return "ExpenseTable [category=" + category + ", amount=" + amount + ", date=" + date + ", description="
                + description + ", time=" + time + "]";
    }
    public void setDateTime(String string) {
        
        throw new UnsupportedOperationException("Unimplemented method 'setDateTime'");
    }
}
    
