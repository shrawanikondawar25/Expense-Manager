package com.firestore.expense;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Transaction {
    private String category;
    private double amount;
    private LocalDate date;
    private String description;
    private LocalDateTime dateTime;
    

    // Constructor
    public Transaction(String category, double amount, LocalDate date, String description, LocalDateTime dateTime) {
        this.category = category;
        this.amount = amount;
        this.date = date;
        this.description = description;
        this.dateTime = dateTime;
    }

    // Getters and Setters
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "category='" + category + '\'' +
                ", amount=" + amount +
                ", date=" + date +
                ", description='" + description + '\'' +
                ", dateTime=" + dateTime +
                '}';
    }

    public Object getType() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getType'");
    }
}


