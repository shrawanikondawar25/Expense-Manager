package com.firestore.controller.login;

import java.util.HashMap;
import java.util.Map;

import com.firestore.expense.ExpenseTracKer;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class LoginPage extends Application {

    private Stage prStage;
    private Scene scene;
    @Override
    public void start(Stage primaryStage) {

        ExpenseTracKer.initializeFirebase();
        primaryStage.setTitle("Expense Manager");

        
        Scene loginScene = createLoginScene(primaryStage);

        
        primaryStage.setScene(loginScene);
        prStage = primaryStage;
        primaryStage.show();
    }

    private Scene createLoginScene(Stage primaryStage) {
    
       
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setPadding(new Insets(20, 20, 20, 20));
        gridPane.setVgap(20);
        gridPane.setHgap(20);
    
        Image image = new Image("images/i2.jpg"); 
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(400); 
        imageView.setPreserveRatio(true);
        
        Label emailLabel = new Label("Email");
        gridPane.add(emailLabel, 0, 1);

        
        TextField emailTextField = new TextField();
        emailTextField.setPromptText("Email");
        gridPane.add(emailTextField, 1, 1);

        
        Label passwordLabel = new Label("Password");
        gridPane.add(passwordLabel, 0, 2);

        
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        gridPane.add(passwordField, 1, 2);

        
        CheckBox rememberMeCheckBox = new CheckBox("Remember Me");
        gridPane.add(rememberMeCheckBox, 1, 3);
        GridPane.setHalignment(rememberMeCheckBox, javafx.geometry.HPos.CENTER);
        

        
        Button loginButton = new Button("Log In");
        loginButton.setStyle("-fx-background-color: #ffcc00;");
        gridPane.add(loginButton, 1, 4);
        GridPane.setMargin(loginButton, new Insets(20, 0, 20, 0));
        GridPane.setHalignment(loginButton, javafx.geometry.HPos.CENTER);
        loginButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                ExpenseTracKer ex = new ExpenseTracKer();
                if(ex.authaunticate(emailTextField.getText(),passwordField.getText())){
                    initilizeExpenseTrac();

                }
            }
            
        });
        
        Label forgotPasswordLabel = new Label("Forgot password?");
        gridPane.add(forgotPasswordLabel, 1, 5);
        GridPane.setHalignment(forgotPasswordLabel, javafx.geometry.HPos.CENTER);

       
        Label signUpLabel = new Label("Don't have an account? Sign up here.");
        signUpLabel.setOnMouseClicked(event -> {
            Scene signupScene = createSignupScene(primaryStage);
            primaryStage.setScene(signupScene);
        });
        gridPane.add(signUpLabel, 1, 6);


        
        VBox vbox = new VBox(imageView,gridPane);
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color : rgb(252,223,169)");
        
        


        Scene sc = new Scene(vbox, 1000, 900);
        scene = sc;
        return sc;
    }

    private void initilizeExpenseTrac() {
        
        ExpenseTracKer expense= new ExpenseTracKer();
        expense.setStage(prStage);
        Scene scene = expense.setupMainScene(this::handleLogout);
        expense.setScene(scene);
        prStage.setScene(scene);

    }
    void handleLogout(){
        prStage.setScene(scene);
    }
    private Scene createSignupScene(Stage primaryStage) {
        
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(10);
        gridPane.setHgap(10);


        Image image = new Image("images/i2.jpg"); 
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(400); 
        imageView.setPreserveRatio(true);
        

        

        
        Label usernameLabel = new Label("Username");
        gridPane.add(usernameLabel, 0, 1);

        
        TextField usernameTextField = new TextField();
        usernameTextField.setPromptText("Username");
        gridPane.add(usernameTextField, 1, 1);

        
        Label emailLabel = new Label("Email");
        gridPane.add(emailLabel, 0, 2);

        
        TextField emailTextField = new TextField();
        emailTextField.setPromptText("Email");
        gridPane.add(emailTextField, 1, 2);

        
        Label passwordLabel = new Label("Password");
        gridPane.add(passwordLabel, 0, 3);

        
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        gridPane.add(passwordField, 1, 3);

        
        Label confirmPasswordLabel = new Label("Confirm Password");
        gridPane.add(confirmPasswordLabel, 0, 4);

        
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");
        gridPane.add(confirmPasswordField, 1, 4);

        
        Button signupButton = new Button("Sign Up");
        signupButton.setStyle("-fx-background-color: #ffcc00;");
        gridPane.add(signupButton, 0, 5, 2, 1); 
        GridPane.setMargin(signupButton, new Insets(10, 0, 10, 0));
        GridPane.setHalignment(signupButton, javafx.geometry.HPos.CENTER);
        signupButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                ExpenseTracKer ex = new ExpenseTracKer();
                Map<String,Object> map = new HashMap<>();
                map.put("username", usernameTextField.getText());
                map.put("email", emailTextField.getText());
                map.put("password", passwordField.getText());

                ex.addData("users", emailTextField.getText(), map);

            }
        }); 

        
        Label backToLoginLabel = new Label("Back to Login");
        backToLoginLabel.setOnMouseClicked(event -> {
            Scene loginScene = createLoginScene(primaryStage);
            primaryStage.setScene(loginScene);
        });
        gridPane.add(backToLoginLabel, 1, 6);

        
        VBox vbox = new VBox(imageView,gridPane);
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color : rgb(252,223,169)");

    

        

        
        return new Scene(vbox, 1000, 900);
    }
    public static void main(String[] args) {
        launch(args);
        
    }

    
}
